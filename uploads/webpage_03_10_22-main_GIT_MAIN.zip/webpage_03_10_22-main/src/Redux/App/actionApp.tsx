import { AUTHDATA } from "./typeApp";
export const authData = ()=>{
    return {
        type : AUTHDATA
    }
}