import React from "react";
function Details(){
    return(
        <section className="common">
	<div className="section-two">
	<h2>Details</h2>
	<p>
        Lorem ipsum dolor amet, consectetur adipiscing elit. Phasellus ut magna turpis. Proin non fringilla nisi. Suspendisse malesuada felis id nibh<br/>
	ullamcorper vulputate. Nam commodo dolor eu sem feugiat, id hendrerit nunc vestibulum. Quisque scelerisque elementum sem, id lobortis arcu pellentesque sit.<br/>
	lacinia lobortis aliquet. Quisque pharetra arcu eget tortor malesuada faucibus. Praesent tempor lobortis facilisis. Phasellus et mattis tellus. Duis consectetur augue<br/>
	 lacus, quis fringilla risus varius eget. Integer ut est sollicitudin, pulvinar est non, consectetur elit.
	 </p>
	</div>
</section>
    )
}

export default Details