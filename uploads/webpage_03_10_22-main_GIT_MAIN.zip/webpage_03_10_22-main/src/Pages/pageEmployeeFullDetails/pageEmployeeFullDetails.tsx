import Header from "../../component/Header/header";
import Home from "../../component/Home/home";
import EmployeeFullDetails from "../../component/employeeFullDetails/employeefulldetails";
import Footer from "../../component/Footer/footer";
 function PageEmployeeFullDetails(){
    return(
        <div>
            <Header/>
            <Home/>
            <EmployeeFullDetails/>
            <Footer/>
        </div>
    )
 }
 export default PageEmployeeFullDetails