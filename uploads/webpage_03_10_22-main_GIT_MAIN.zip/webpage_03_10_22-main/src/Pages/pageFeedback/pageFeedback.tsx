import Home from '../../component/Home/home'
import Feedback from '../../component/Feedback/feedback'

function PageFeedback(){
    return(
        <div>
            <Home/>
            <Feedback/>
        </div>
    )
}
export default PageFeedback
