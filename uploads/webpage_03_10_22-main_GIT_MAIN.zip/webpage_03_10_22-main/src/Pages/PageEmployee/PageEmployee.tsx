import Home from '../../component/Home/home'
import Employee from '../../component/EmployeeDetails/Employee'

function PageEmployee(){
    return(
        <div>
            <Home/>
            <Employee/>
        </div>
    )
}
export default PageEmployee