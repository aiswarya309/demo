import Home from '../../component/Home/home'
import NavAbout from '../../component/NavAbout/NavAbout'
function PageAbout(){
    return(
        <div>
            <Home/>
            <NavAbout/>
        </div>
    )
}
export default PageAbout